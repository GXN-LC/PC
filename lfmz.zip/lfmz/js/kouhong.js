$(function(){
	$("[name=ssuo]").focus(function(){
		var sou=$(this).val();
		if(sou=="搜商品"){
			$(this).val("");
		}
	});
	$("[name=ssuo]").blur(function(){
		var sou=$(this).val();
		if(sou==""){
			$(this).val("搜商品");
		}
	});
	
})
